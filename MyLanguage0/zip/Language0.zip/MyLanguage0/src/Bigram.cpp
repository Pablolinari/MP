/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cppFiles/class.cc to edit this template
 */

/* 
 * File:   Bigram.cpp
 * Author: pablo
 * 
 * Created on 6 de marzo de 2023, 16:27
 */


#include "Bigram.h"
#include <string>

Bigram::Bigram(const std::string& text){
    if(text.size()==2){
        _text = text;
    }
    else{
        _text = "__";
    }
}

Bigram::Bigram(char first, char second){
    _text.push_back(first);
    _text.push_back(second);
}

std::string Bigram::getText()const{
    return _text;
}

 std::string Bigram::toString() const{
     return _text;
 }
 
 const char& Bigram::at(int index) const{
     if(index==1 || index ==0){
         return _text.at(index);
     }
     else{
         throw std::out_of_range("const char& Bigram::at(int index) const // invalid index");
     }
     
 }
 
  char& Bigram::at(int index){
     if(index==1 || index ==0){
         return _text.at(index);
     }
     else{
         throw std::out_of_range("const char& Bigram::at(int index) const // invalid index");
     }
     
 }
 
 bool isValidCharacter(char character , const std::string &validCharacters){
     bool is_valid = false;
     for(int x=0; x< validCharacters.size()-1; x++){
         if(character == validCharacters.at(x)){
             is_valid = true;
         }
     }
     return is_valid;
     
     
 }
 
 void toUpper(Bigram &bigram){
     char a = toupper(bigram.at(0));
     char b = toupper(bigram.at(1));
     Bigram bigram_(a,b);
     bigram = bigram_;
 }