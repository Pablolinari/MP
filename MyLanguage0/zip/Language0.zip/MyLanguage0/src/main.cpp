/*
 * Metodología de la Programación: Language0
 * Curso 2022/2023
 */




/**
 * This program reads a text (without spaces) with a undefined number of 
 * characters and a text with two characters (bigram). It finds the bigrams 
 * contained in the first text, storing them in an array of Bigram. 
 * After that, the bigrams of the array are shown in the standard output. 
 * Then it converts to uppercase the bigrams in the array that are equals to the 
 * bigram of the second text. Finally the bigrams of the array are shown again 
 * in the standard output. 
 * Running example:
 * > language0 < data/SimpleText.txt
 */
#include<iostream>
#include<string>
#include"Bigram.h"
using namespace std;

int main(int argc, char* argv[]) {
    // This string contains the list of characters that are considered as
    // valid within a word. The rest of characters are considered as
    // separators
    const string validCharacters = "abcdefghijklmnopqrstuvwxyz\xE0\xE1\xE2\xE3\xE4\xE5\xE6\xE7\xE8\xE9\xEA\xEB\xEC\xED\xEE\xEF\xF0\xF1\xF2\xF3\xF4\xF5\xF6\xF8\xF9\xFA\xFB\xFC\xFD\xFE\xFF";

    // Read a text
    string text , bigram;
    cout<<"Insert text: ";
    cin>>text;
    
    // Read a bigram (tex with two characters)
   
    cout << "Insert bigram : ";
    cin>>bigram;
    
    // Find the bigrams in text and put them in an array of Bigrams
    Bigram bigrams[100];
    

    int used=0;
    
    for(int i = 0; i<text.size()-1;i++){
        char a = tolower(text.at(i));
        char b= tolower(text.at(i+1));
        
        if((isValidCharacter(a,validCharacters))&&(isValidCharacter(b,validCharacters))){
            bigrams[used] = Bigram(a,b);
            used++;
        }
    }
    
    // Show the bigrams stored in the array
    cout<< endl<<used;
     cout << endl<<endl;
    for(int j=0; j <used; j++){
        cout <<endl<< bigrams[j].toString();
    }
    
    // Convert to uppercase the bigrams in the array that are equals to input bigram
        for(int j=0; j <used; j++){
        if(bigrams[j].toString()== bigram){
            toUpper(bigrams[j]);
        }
    }
    // Show again the bigrams stored in the array
    cout<< endl<<used;
    cout << endl<<endl;
    
    for(int j=0; j <used; j++){
        cout <<endl<< bigrams[j].toString();
    }

}